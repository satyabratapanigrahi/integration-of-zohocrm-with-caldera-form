<label><?php esc_html_e( 'Environment', 'integration-zoho-calderaforms' ); ?> </label>
<div class="caldera-config-field">
		<select class="block-input field-config" name="{{_name}}[izcf_zoho_environment]" id="izcf_zoho_environment">
			<option value="1" {{#is context value="1"}}selected="selected"{{/is}}><?php esc_html_e( 'Production', 'integrate-caldera-forms-zoho' ); ?></option>
            <!-- <option value="0" {{#is context value="0"}}selected="selected"{{/is}}><?php  //esc_html_e( 'Sandbox', 'integration-zoho-calderaforms' ); ?></option> -->
		</select>
	</div>
</div>

<div class="caldera-config-group">
    <label><?php esc_html_e( 'Zoho Authentication Id', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="text" class="block-input field-config required" id="izcf_zoho_org_id" name="{{_name}}[izcf_zoho_org_id]" value="{{izcf_zoho_org_id}}" required="required">
        <div class="description">
            <?php echo __( 'Get your API key to <a href="https://help.zoho.com/articleView?id=000325251&type=1&mode=1">Click Here</a>', 'integration-zoho-calderaforms' ); ?>
            
        </div>
    </div>
</div>

<div class="caldera-config-group">
    <label><?php esc_html_e( ' Zoho Debugging Email ', 'integration-zoho-calderaforms'); ?> </label>
    <div class="caldera-config-field">
        <input type="email" class="block-input field-config required" id="izcf_zoho_debug_email" name="{{_name}}[izcf_zoho_debug_email]" value="{{izcf_zoho_debug_email}}" required="required">
        <div class="description">
            <?php esc_html_e( 'Provide a valid Email for debugging.', 'integrate-caldera-forms-zoho' ) ?>
        </div>
    </div>
</div>

<div class="caldera-config-group">
	<label><?php esc_html_e( 'Zoho Object', 'integration-zoho-calderaforms' ); ?> </label>
	<div class="caldera-config-field">
		<select class="block-input field-config" name="{{_name}}[izcf_zoho_obj]" id="izcf_zoho_obj" required="required">
             <option value = "" selected="selected" selected disabled >---Choose Object---</option>
			<!--  <option value="" ><?php // esc_html_e( '---select Object---', 'integrate-caldera-forms-zoho' ); ?></option>  -->
            <option value="Leads"{{#is izcf_zoho_obj value="Leads"}}selected="selected"{{/is}} ><?php esc_html_e( 'Leads', 'integrate-caldera-forms-zoho' ); ?></option>
            <option value="Contacts" {{#is izcf_zoho_obj value="Contacts"}}selected="selected"{{/is}}><?php esc_html_e( 'Contacts', 'integrate-caldera-forms-zoho' ); ?></option>
             <option value="Accounts" {{#is izcf_zoho_obj value="Accounts"}}selected="selected"{{/is}}><?php esc_html_e( 'Accounts', 'integrate-caldera-forms-zoho' ); ?></option>
		</select>
         <button class ="button caldera-zoho-show-alias"  id= "btn" type="button"><?php echo __( 'Show Alias', 'integration-zoho-calderaforms' ); ?></button>

	</div>
</div>

<!-- <div class="caldera-config-group">
    <label><?php //esc_html_e( 'First Name', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind required" id="izcf_zoho_first_name" name="{{_name}}[izcf_zoho_first_name]" value="{{izcf_zoho_first_name}}" required="required">
    </div>
</div>

<div class="caldera-config-group">
    <label><?php //esc_html_e( 'Last Name', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind" id="izcf_zoho_last_name" name="{{_name}}[izcf_zoho_last_name]" value="{{izcf_zoho_last_name}}">
    </div>
</div>

<div class="caldera-config-group">
    <label><?php  //sc_html_e( 'Your Email', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="email" class="block-input field-config magic-tag-enabled caldera-field-bind required" id="izcf_zoho_email" name="{{_name}}[izcf_zoho_email]" value="{{izcf_zoho_email}}" required="required">
    </div>
</div>

<div class="caldera-config-group">
    <label><?php  //esc_html_e( 'Company Name', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind" id="izcf_zoho_company" name="{{_name}}[izcf_zoho_company]" value="{{izcf_zoho_company}}">
    </div>
</div>

<div class="caldera-config-group">
    <label><?php  //esc_html_e( 'Title', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind" id="izcf_zoho_title" name="{{_name}}[izcf_zoho_title]" value="{{izcf_zoho_title}}" >
    </div>
</div>

<div class="caldera-config-group">
    <label> <?php  //esc_html_e( 'Mobile No', 'integration-zoho-calderaforms' ); ?> </label>
    <div class="caldera-config-field">
        <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind" id="izcf_zoho_mobile" name="{{_name}}[izcf_zoho_mobile]" value="{{izcf_zoho_mobile}}">
    </div>
</div> -->

<!-- user input tabluar form -->
 <h4><?php echo __( 'Caldera Zoho Field Mappings Setup', 'caldera-forms-Zoho' ); ?></h4>
<table class="wp-list-table widefat fixed striped posts izcf-Zoho-mappings">
    <thead>
        <tr>
            <th style="width:45%;">
                <?php echo __( 'Zoho Field Aliases', 'caldera-forms-Zoho' ); ?>
            </th>
            <th style="width: 45%">
                <?php echo __( 'Values to Send', 'caldera-forms-Zoho' ); ?>
            </th>
            <th style="width: 10%">
            </th>
        </tr>
    </thead>
    <tbody>
        {{#each izcf_zoho_field_mappings_value as | izcf_zoho_field_mapping_value key|}}
        <tr>
            <td>
                <select type="text" class="block-input field-config" id="zohoid" name="{{../_name}}[izcf_zoho_field_mappings_alias][]"  value="{{lookup ../izcf_zoho_field_mappings_alias key}}">
                <option value = ""   selected="selected">---Choose Alias---</option>
            </select>
            </td>
            <td>
                <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind required" name="{{../_name}}[izcf_zoho_field_mappings_value][]" value="{{lookup ../izcf_zoho_field_mappings_value key}}">
            </td>
            <td style="text-align: center;">
                <button class="button caldera-zoho-remove-mappings" type="button">&times;</button>
            </td>
        </tr>
        {{else}}
        <tr>
            <td>
                <select type="text" class="block-input field-config" id = "newZohoId" name="{{../_name}}[izcf_zoho_field_mappings_alias][]" value="">
                <option value = ""   selected="selected">---Choose Alias---</option>

                  </select>    
            </td>
            <td>
                <input type="text" class="block-input field-config magic-tag-enabled caldera-field-bind required" name="{{../_name}}[izcf_zoho_field_mappings_value][]" value="">
            </td>
            <td style="text-align: center;">
                <button class="button caldera-zoho-remove-mappings" type="button">&times;</button>
            </td>
        </tr>
        {{/each}}
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3" style="text-align:center;">
                <button class="button caldera-zoho-add-mappings" type="button"><?php echo __( 'Add Another Mapping', 'caldera-forms-zoho' ); ?></button>
            </td>
        </tr>
    </tfoot>
</table>





