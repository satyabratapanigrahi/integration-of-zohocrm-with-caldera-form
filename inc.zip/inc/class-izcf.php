<?php
/**
 * Class IZCF file.
 * 
 * @package IZCF
 * @version 0.0.1
 */

#Wed Oct 23 04:40:23 PDT 2019
// AUTHTOKEN=6a6d02bc5a495056529aa999cf75dd28

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}


if ( ! class_exists( 'IZCF', false ) ) :

    /**
     * ICFS Class
     */
	class IZCF {
		/**
         * Member Variable
         *
         * @var object instance
         */
        private static $instance;

        /**
         * Returns the *Singleton* instance of this class.
         *
         * @return Singleton The *Singleton* instance.
         */
        public static function get_instance() {
            if ( null === self::$instance ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Class Constructor
         * 
         * @since  0.0.1
         * @return void
         */
		public function __construct() {

			// Load text domain
			add_action( 'plugins_loaded', array( $this, 'izcf_plugin_load_textdomain' ) );
			// Check whether Caldera form is active or not
			register_activation_hook( __FILE__, array( $this, 'izcf_integration_activate' ) );
	    	
	    	//Register Processor Hook
	   		add_filter( 'caldera_forms_get_form_processors',  array( $this, 'izcf_register_processor' ) );
	   		add_action( 'admin_enqueue_scripts', array( $this, 'izcf_enqueue_scripts' ) );
	   		// Ajax call
	   		add_action( 'wp_enqueue_scripts', array( $this, 'izcf_enqueue_scripts' ) );
	   		add_action( 'wp_ajax_read_me_later', array( $this, 'read_me_later' ) );
      add_action( 'wp_ajax_nopriv_read_me_later', array( $this, 'read_me_later' ) );
      add_action( 'wp_ajax_my_action', 'read_me_later' );
      add_action( 'wp_ajax_nopriv_my_action', 'read_me_later' );

		}

		

		/**
	 *
	 * @uses Loads the required stylesheets
	 *
	 * @since 1.0.0
	 *
	 * @param $hook
	 * @return mixed
	 */

	public function izcf_enqueue_scripts( $hook ){
		//Register and Enque the JS file in WordPress Admin
	    wp_register_script( 'cf_zoho_integration_script', plugins_url( '/js/cf_zoho_integration.js', __FILE__ ) );
	    wp_enqueue_script( 'cf_zoho_integration_script' );	
	    // Ajax enqueue script
	    wp_enqueue_script( 'ajax-script', get_template_directory_uri() . '/js/cf_zoho_integration.js', array('jquery') );
      	wp_localize_script( 'cf_zoho_integration_script', 'zoho_data', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );	
	}

		/**
		 * Check Caldera Forms is active or not
		 *
		 * @since 1.0
		 */
		public function izcf_integration_activate( $network_wide ) {
			 if( ! function_exists( 'caldera_forms_load' ) ) {
			    wp_die( 'The "Caldera Forms" Plugin must be activated before activating the "Caldera Forms - Zoho Integration" Plugin.' );
			}
		}

		
		
	   	/**
		  * Load plugin textdomain.
		  *
		  * @since 1.0
		  */

		public function izcf_plugin_load_textdomain() {
			load_plugin_textdomain( 'integration-zoho-calderaforms', false, basename( dirname( __FILE__ ) ) . '/languages' );
		}

		/**
		  * Add Our Custom Processor
		  *
		  * @uses "caldera_forms_get_form_processors" filter
		  *
		  * @since 0.0.1
		  *
		  * @param array $processors
		  * @return array Processors
		  *
		  */

		public function izcf_register_processor( $processors ) {
		  	$processors['cf_zoho_integration'] = array(
				'name'              =>  __( 'Zoho Integration', 'integration-zoho-calderaforms' ),
				'description'       =>  __( 'Send Caldera Forms submission data to zoho using Zoho REST API.', 'integration-zoho-calderaforms' ),
				'pre_processor'		=>  array( $this, 'cf_zoho_integration_processor' ),
				'template' 			=>  __DIR__ . '/config.php'
			);
			return $processors;
		}


		/**
	 	 * At process, get the post ID and the data and save in zoho using zoho organization id
		 *
		 * @param array $config Processor config
		 * @param array $form Form config
		 * @param string $process_id Unique process ID for this submission
		 *
		 * @return void|array
		 */

		public function cf_zoho_integration_processor( $config, $form, $process_id ) {
			
			 if( !isset( $config['izcf_zoho_environment'] ) || empty($config['izcf_zoho_environment'] ) ) {
			    return;
			 }

			 if( !isset( $config['izcf_zoho_org_id'] ) || empty( $config['izcf_zoho_org_id'] ) ){
			     return;
		 	}

		 	if( !isset( $config['izcf_zoho_debug_email'] ) || empty( $config['izcf_zoho_debug_email'] ) ){
		    return;
		 	}

		 	if( !isset( $config['izcf_zoho_obj'] ) || empty( $config['izcf_zoho_obj'] ) ){
				return;
		   	}

			 $zoho_environment = Caldera_Forms::do_magic_tags( $config['izcf_zoho_environment'] );

			 $zoho_org_id = Caldera_Forms::do_magic_tags( $config['izcf_zoho_org_id'] );
			 $zoho_debugging_email = Caldera_Forms::do_magic_tags( $config['izcf_zoho_debug_email'] );

			 $zoho_object = Caldera_Forms::do_magic_tags( $config['izcf_zoho_obj'] );

			 $zoho_field_aliases = $config['izcf_zoho_field_mappings_alias'];
	  	$zoho_field_values_base = $config['izcf_zoho_field_mappings_value'];
	  	$zoho_field_data = [];
	  	foreach($zoho_field_values_base as $key => $zoho_field_value) {
	    	$zoho_field_data[$zoho_field_aliases[$key]] = trim( Caldera_Forms::do_magic_tags($zoho_field_value) );

	  	}
	  

			      $xml = '<?xml version="1.0" encoding="UTF-8"?><'.$zoho_object.'>
			       <row no="1">
			       ';
					foreach ($zoho_field_data as $key => $value) {
					$xml .= ' <FL val= "'.$key.'">' .$value. ' </FL>';
					} 

					$xml .= ' </row> </'.$zoho_object.'>';


		    $url ="https://crm.zoho.com/crm/private/xml/".$zoho_object."/insertRecords";
		    $query="authtoken=".$zoho_org_id."&scope=crmapi&newFormat=1&xmlData=".$xml;

           
		    $ch = curl_init();
		    /* set url to send post request */
		    curl_setopt($ch, CURLOPT_URL, $url);
		    /* allow redirects */                                    
		    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		    /* return a response into a variable */
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    /* times out after 30s */
		    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		    /* set POST method */
		    curl_setopt($ch, CURLOPT_POST, 1);
		    /* add POST fields parameters */
		    curl_setopt($ch, CURLOPT_POSTFIELDS, $query);// Set the request as a POST FIELD for curl.

		    //Execute cUrl session
		    $response = curl_exec($ch);
		
		 
		   curl_close($ch);
		       
    	    
		   print_r($response);

	
		}


		//    $response = wp_remote_post($url, array(
  //       'method' => 'POST',
  //     'headers' => $headers,
    
  //       'sslverify' => false,
  //      'body' =>  $query)
  //  			);
		// print_r($response);exit;


	
		public function print_b($data){
			echo "<pre>";
			print_r($data); die;
		}



	/**
     * Callback function using 'read-me-later' (ajax-call)
     */
    
	public function read_me_later() {

    

     
	    $response= wp_remote_get('https://crm.zoho.com/crm/private/json/'.$_GET['object'].'/getFields?authtoken='.$_GET['key'].'&scope=crmapi');

	    /**
	     * Get values in JSON format, filetr the array by using array functions. And send it to AJAX call.
	     */
	    

	      $zohoField= wp_remote_retrieve_body( $response);
	     

		      try {
		      	$dataArray = json_decode($zohoField, true);
		      	$sections = $dataArray['Leads']['section'];

		      	$res = [];
		      	foreach ($sections as $key => $section) {
		      		 $labels = $section['FL'];
		      		 foreach ($labels as $i => $label) {
		      				array_push($res, $label);
		      		 }
		      	}

		      	

		        $data = array_column($res, 'label');

		        $html = '<option value="">Choose option</option>';
		      
		      	foreach ($data as $d) {
		      		$html .= '<option value="'.$d.'">'.$d.'</option>';
		      	}

			
		      	 wp_send_json_success($html);
		       wp_die();
		 		
		      }catch (Exception $e){
		      	$this->print_b($e);
		      }
		      
		}



	}


	/**
     * Calling class using 'get_instance()' method
     */
    IZCF::get_instance();

endif;

