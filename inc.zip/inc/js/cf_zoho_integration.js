jQuery( function(){
    var block_first_row = function () {
        jQuery(".izcf-zoho-mappings input.field-config:first").prop('readonly', 'readonly');
        jQuery(".izcf-zoho-mappings input.field-config:first").parent().parent().addClass('izcf-required');
   
    };

    block_first_row();
    jQuery(window).on('load', block_first_row);
    jQuery("body").on('click', '.caldera-zoho-add-mappings', function() {
        jQuery("tbody tr:last").clone().appendTo("tbody");
        jQuery("tbody tr:last input").val("");
        jQuery("tbody tr:last input").removeProp("readonly");
 
    });

    jQuery("body").on('click', '.caldera-zoho-remove-mappings', function() {
        var $parentTr = jQuery(this).parent().parent();
        if($parentTr.hasClass('izcf-required')) {
            alert("Email is a required mapping for Zoho Integration!");
            return;
        }
        if(jQuery('.caldera-zoho-remove-mappings').length > 1) {
            $parentTr.remove();
        }
    });
 // for apikey and object validation
  jQuery("body").on('click', '.caldera-zoho-show-alias', function (e) {
              var apiKey = jQuery("#izcf_zoho_org_id").val();
              var keyLength = apiKey.replace(/ /g, '').length;

              if (keyLength !== 32) 
              {
                  alert("Please Enter a Valid API Key");

              }
              var zohoObject = jQuery("#izcf_zoho_obj").val();



              if (!zohoObject) {
                  alert("Please Choose The Object !");
                  return false;
              }

              if (!apiKey || !zohoObject) {
                  return false;
              }

              jQuery.ajax({
                  type: "get",
                  url: zoho_data.ajax_url,
                  data: {
                      action: 'read_me_later',
                      security: zoho_data.check_nonce,
                      key: apiKey,
                      object: zohoObject,
                  }, success: function (data) {

                     const options = data.data;
                     console.log(options);
                     
                     jQuery('#zohoid').html(options);
                      const dataWhileOnLoad = JSON.parse(localStorage.getItem('dataWhileOnLoad'));
                       console.log(dataWhileOnLoad);
                      if (dataWhileOnLoad) jQuery('#zohoid').val(dataWhileOnLoad.alias);
                      var testObject = {};

      //                  var obj = <?php echo $res; ?>
      // console.log(obj.expression.$_GET['object']. section.dv);
                      // $("#zohoid table table tr:first").val();
                      $(".izcf-zoho-mappings tr table table tr:first").val();

                      const dynamicDataWhileOnLoad = JSON.parse(localStorage.getItem('dynamicDataWhileOnLoad'));
                      console.log(dynamicDataWhileOnLoad);
                      if(dynamicDataWhileOnLoad) jQuery('.izcf-zoho-mappings tr').val(dynamicDataWhileOnLoad.dynamicAlias);

                      const dynamicDataWhileOnLoad10 = JSON.parse(localStorage.getItem('dynamicDataWhileOnLoad10'));
                      console.log(dynamicDataWhileOnLoad10);
                      if(dynamicDataWhileOnLoad10) jQuery('.izcf-zoho-mappings tr').val(dynamicDataWhileOnLoad10.dynamicAlias10);
                      var dynamicObject ={};

                      const dynamicDataWhileOnLoad16 = JSON.parse(localStorage.getItem('dynamicDataWhileOnLoad16'));
                      console.log(dynamicDataWhileOnLoad16);
                      if(dynamicDataWhileOnLoad16) jQuery('.izcf-zoho-mappings tr').val(dynamicDataWhileOnLoad16.dynamicAlias16);
                      var dynamicObject ={};


                  }
        });
    });

      //  store dropdown value in local Storage

                    var testObject = {};
                    var dynamicObject = {};
                    jQuery(document).ready(function () {

                    $(document).on('change','.izcf-zoho-mappings tr' ,function(){
                    //
                     var $item = $(this).closest("tr").find('td');
                     var indexOfRow = $item[0];
                     var colIndex = $(this).parent().children().index($(this));
                     console.log(colIndex);




                    var dynamicDropData = ($(indexOfRow).find('select:first').val()) ;
                    console.log(dynamicDropData);


                    var dynamicData = {dynamicAlias : dynamicDropData};

                    console.log(dynamicData);
       
                localStorage.setItem('dynamicDataWhileOnLoad', JSON.stringify(dynamicData));
                var dynamicDataWhileOnLoad = localStorage.getItem('dynamicDataWhileOnLoad');
                  console.log(dynamicDataWhileOnLoad);
                        });


                $('#zohoid').on('change', function() {
                var test = ((testObject.alias = this.value));
                    // console.log(test);

                localStorage.setItem('dataWhileOnLoad', JSON.stringify(testObject));
                      });
                var dataWhileOnLoad = localStorage.getItem('dataWhileOnLoad');
                   

                });
});